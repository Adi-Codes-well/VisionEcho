# AI Vision Assistant

This project uses GLIP for object detection, OCR for text extraction, and TTS for audio feedback.
